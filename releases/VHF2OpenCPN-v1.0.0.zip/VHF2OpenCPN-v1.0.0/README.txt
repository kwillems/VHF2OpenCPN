VHF2OpenCPN 1.0.0
===================

Deze ZIP bevat de twee VHF2OpenCPN-kaartlagen en de bijbehorende
UserIcons voor OpenCPN.

INHOUD

layers/
    VHFinfo_Nederland.gpx
    RWS_Marifoonborden.gpx

UserIcons/
    De bij de kaartlagen behorende VHF-iconen.

BELANGRIJK

De map UserIcons is een verplicht onderdeel van de installatie.
Zonder deze iconen worden de VHF-symbolen in OpenCPN niet correct
weergegeven.

Na installatie van nieuwe of gewijzigde UserIcons moet OpenCPN
opnieuw worden gestart.

Voor volledige installatie-instructies en projectinformatie:
https://github.com/kwillems/VHF2OpenCPN
